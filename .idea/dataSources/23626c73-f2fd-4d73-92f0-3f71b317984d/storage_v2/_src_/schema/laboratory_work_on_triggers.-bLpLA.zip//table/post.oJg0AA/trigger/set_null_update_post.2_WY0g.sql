create definer = root@localhost trigger set_null_update_post
    before UPDATE
    on post
    for each row
begin
if (old.experience=0) then
set new.experience = null;
end if;
end;

