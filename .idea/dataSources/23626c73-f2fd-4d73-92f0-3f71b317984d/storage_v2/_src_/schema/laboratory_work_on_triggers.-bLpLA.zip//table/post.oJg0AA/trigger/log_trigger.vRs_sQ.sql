create definer = root@localhost trigger log_trigger
    after INSERT
    on post
    for each row
begin
insert into log_table_for_post values (null, 'insert', new.id_post, new.post_name, new.experience, date(now()));
end;

