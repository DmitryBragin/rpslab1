create definer = root@localhost trigger restrict_delete_post
    before DELETE
    on post
    for each row
begin
if not((select count(id_worker) from worker where post_id=old.id_post)=0)
then set @mess_text = concat('"', old.id_post,'"', old.post_name, '"', " the post can't be removed, as there are employees with such a post");
signal sqlstate '45000' set message_text = @mess_text;
end if;
end;

