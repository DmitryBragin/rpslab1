create view service_prices as
select `airport`.`service`.`id_service`    AS `id_service`,
       `airport`.`service`.`service_name`  AS `service_name`,
       `airport`.`service`.`service_price` AS `service_price`,
       `airport`.`service`.`worker_id`     AS `worker_id`
from `airport`.`service`
where (`airport`.`service`.`service_price` > 1500);

