create
    definer = root@localhost function experience_for_post(experience int) returns char(150)
begin
declare answer char(150);
if (experience=1) then set answer='no post';
elseif (experience=2) then set answer='possible post: Administrator, Consultant, Call-center operator';
elseif (experience=3) then set answer='possible post: Communication technician, Specialist in debt collection, System administrator assistant';
elseif (experience=4) then set answer='possible post: Telephone station engineer, Electrician of station equipment, Telephonist';
elseif (experience>4 and experience<7) then set answer='possible post: all posts except for The chief of the telephone station';
elseif (experience>=7) then set answer='possible post: The chief of the telephone station and all other post';
end if;
return answer;
end;

