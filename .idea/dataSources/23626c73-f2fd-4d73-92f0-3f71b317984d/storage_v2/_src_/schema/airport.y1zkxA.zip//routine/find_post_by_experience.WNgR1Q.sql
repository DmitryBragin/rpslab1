create
    definer = root@localhost procedure find_post_by_experience(IN experience_for_post int)
begin
case
when experience_for_post =2 then select * from post where experience= experience_for_post order by post_name;
when experience_for_post =3 then select * from post where experience= experience_for_post order by post_name;
when experience_for_post =4 then select * from post where experience= experience_for_post order by post_name;
when (experience_for_post >4 and experience_for_post <7) then select * from post where experience<experience_for_post order by post_name;
when experience_for_post >=7 then select * from post order by post_name;
else select 'no post';
end case;
end;

