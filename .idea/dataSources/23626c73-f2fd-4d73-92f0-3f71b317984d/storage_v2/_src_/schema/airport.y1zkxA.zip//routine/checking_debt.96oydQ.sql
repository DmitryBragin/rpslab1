create
    definer = root@localhost procedure checking_debt(IN n int)
begin
select client_debt_id, if(client_debt_id=n, 'yes','no') as has_debt from debt where client_debt_id=n;
end;

