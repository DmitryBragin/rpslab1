create
    definer = root@localhost function answer(id_client int) returns char(3)
begin
declare result char(3);
select blocker_presence into result from `order` where clients_order_id = id_client;
return result;
end;

