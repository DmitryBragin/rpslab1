create
    definer = root@localhost procedure debt_for_certain_date(IN from_this_date date, IN to_this_date date)
begin
select * from debt where term_debt > from_this_date and term_debt < to_this_date order by term_debt;
end;

