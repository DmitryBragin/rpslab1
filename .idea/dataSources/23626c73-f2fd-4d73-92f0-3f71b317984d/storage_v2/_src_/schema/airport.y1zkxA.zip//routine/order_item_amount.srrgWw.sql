create
    definer = root@localhost function order_item_amount(id_client int) returns int
begin
declare result int;
select sum(service_price*quantity) into result from service inner join order_item on id_service=service_id where order_id in (select id_order1 from `order` where clients_order_id=id_client);
return result;
end;

