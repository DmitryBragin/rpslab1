create definer = root@localhost trigger delete_from_orders
    before DELETE
    on order_item
    for each row
    delete from `order` where `order`.id_order1=old.order_id;

