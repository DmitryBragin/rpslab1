create definer = root@localhost trigger new_order
    before INSERT
    on order_item
    for each row
    insert into `order`(id_order1) values (new.order_id);

