create
    definer = root@localhost procedure station_workers(IN station_name char(30))
begin
select * from worker where station_id in (select id_station from telephone_station where st_name= station_name);
end;

