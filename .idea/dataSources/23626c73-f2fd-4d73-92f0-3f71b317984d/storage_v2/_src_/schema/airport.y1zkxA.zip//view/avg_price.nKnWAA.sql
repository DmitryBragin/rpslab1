create view avg_price as
select count(`airport`.`service`.`id_service`)  AS `count_of_services`,
       avg(`airport`.`service`.`service_price`) AS `avg`
from `airport`.`service`;

