create
    definer = root@localhost procedure worker_services(IN id int)
begin
select id_service, service_name, service_price from service inner join worker on worker_id=id_worker where id_worker=id;
end;

