create
    definer = root@localhost procedure new_service_price_without_cursor(IN price_for_comparisson int, IN discount decimal(9, 2))
begin
declare price decimal (9,2);
declare id int;
declare service_id int;
select min(id_service) into id from service;
select max(id_service) into service_id from service;
while id < (service_id) do
select service_price into price from service where id_service=id;
if (price> price_for_comparisson) then
update service set service_price =price*(1-discount) where id_service=id;
end if;
set id=id+1;
end while;
end;

