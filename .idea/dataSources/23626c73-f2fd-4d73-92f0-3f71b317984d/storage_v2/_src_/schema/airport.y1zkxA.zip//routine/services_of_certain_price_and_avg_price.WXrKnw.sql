create
    definer = root@localhost procedure services_of_certain_price_and_avg_price(IN price_for_comparisson int)
begin
select * from service where service_price>price_for_comparisson;
select * from avg_price;
end;

