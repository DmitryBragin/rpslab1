create
    definer = root@localhost function final_sum(id_client int) returns int
begin
declare select_result char(3);
declare answer int;
declare sum_order int;
select blocker_presence into select_result from `order` where clients_order_id = id_client limit 1;
set sum_order = order_item_amount(id_client);
if (select_result = 'yes') then set answer = sum_order+200;
elseif (select_result = 'no') then set answer = sum_order;
end if;
return answer;
end;

