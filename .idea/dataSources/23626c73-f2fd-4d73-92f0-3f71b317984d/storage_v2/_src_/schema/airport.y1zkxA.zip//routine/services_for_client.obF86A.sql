create
    definer = root@localhost procedure services_for_client(IN id_client int)
begin
select * from service where id_service in (select service_id from order_item where order_id in (select id_order1 from `order` where clients_order_id =id_client));
end;

