create view services_performed_by_the_stations as
select `airport`.`telephone_station`.`id_station` AS `id_station`,
       `airport`.`telephone_station`.`st_name`    AS `st_name`,
       `airport`.`order`.`clients_order_id`       AS `clients_order_id`,
       `airport`.`order`.`company_order_id`       AS `company_order_id`,
       `airport`.`service`.`service_name`         AS `service_name`,
       `airport`.`order_item`.`quantity`          AS `quantity`,
       `airport`.`order`.`order_date`             AS `order_date`
from `airport`.`telephone_station`
         join `airport`.`order`
         join `airport`.`order_item`
         join `airport`.`service`
where ((`airport`.`telephone_station`.`id_station` = `airport`.`order`.`station_info_id`) and
       (`airport`.`order`.`id_order1` = `airport`.`order_item`.`order_id`) and
       (`airport`.`order_item`.`service_id` = `airport`.`service`.`id_service`));

