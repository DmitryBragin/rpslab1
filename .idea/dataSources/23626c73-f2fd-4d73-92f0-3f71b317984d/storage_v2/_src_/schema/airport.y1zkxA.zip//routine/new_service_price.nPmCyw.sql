create
    definer = root@localhost procedure new_service_price(IN price_for_comparisson int, IN discount decimal(9, 2))
begin 
declare done int default 0; 
declare price decimal(9,2); 
declare id int; 
declare price_cursor cursor for select service_price, id_service from service; 
declare continue handler for sqlstate '02000' set done=1; 
open price_cursor; 
while done=0 do 
fetch price_cursor into price, id; 
if price>price_for_comparisson then 
update service set service_price =price*(1-discount) where id_service=id; 
end if; 
end while; 
close price_cursor; 
end;

