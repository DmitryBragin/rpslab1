create
    definer = root@localhost procedure order_item_final_amount(IN i int)
begin
select sum(service_price*quantity) as order_item_final_amount from service inner join order_item on id_service=service_id where order_id in (select id_order1 from orders1 where clients_order_id=i);
end;

